import styled from '@emotion/styled'

export const Table = styled.table`
  border: 1px solid black;
  border-collapse: collapse;
  width: 100%;
`