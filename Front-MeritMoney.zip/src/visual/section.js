import styled from '@emotion/styled'

export const Section = styled.section`
box-sizing: border-box;
overflow:auto;
`