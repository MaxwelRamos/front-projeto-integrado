import styled from '@emotion/styled'

export const Body = styled.body`
box-sizing: border-box;
font-family: Verdana;
color: #1C1C1C;
`