import styled from '@emotion/styled'

export const Head = styled.head`
box-sizing: border-box;
font-family: Verdana;
background-color: #2d49a6;
padding: 15px;
text-align:center;
color: #FFF;
`