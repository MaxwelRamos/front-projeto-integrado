import styled from '@emotion/styled'

export const Select = styled.select`
width: 185px;
height: 34px;
overflow: hidden;
background: papayawhip;
border: 1px solid #ccc;
`;