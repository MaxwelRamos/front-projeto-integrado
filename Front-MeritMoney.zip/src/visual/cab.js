import styled from '@emotion/styled'

export const Cab = styled.th`
  border: 1px solid black;
  border-collapse: collapse;
  text-align: left;
  color: white;
  background-color: #264696;
`