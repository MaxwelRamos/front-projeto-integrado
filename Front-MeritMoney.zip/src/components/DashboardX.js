import React from 'react';

export const DashboardX = () => {

    return(
        <h1>DashboardX</h1>
    );
};