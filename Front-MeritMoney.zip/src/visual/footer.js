import styled from '@emotion/styled'

export const Footer = styled.footer`
  box-sizing: border-box;
	background-color: #2d49a6;
	text-align: center;
	padding: 10px;
`