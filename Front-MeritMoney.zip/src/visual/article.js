import styled from '@emotion/styled'

export const Article = styled.article`
box-sizing: border-box;
width: 100%;
padding: 0 20px;
float:left;
text-align:center;
background-color: #836FFF;
`