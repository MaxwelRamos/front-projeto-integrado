import styled from '@emotion/styled'

export const Th = styled.th`
  border: 1px solid black;
  border-collapse: collapse;
`