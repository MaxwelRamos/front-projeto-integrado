import React from "react";
import { ApplicationRoutes } from "./ApplicationRoutes";

export default function App() {
  return (
    <div className="App">
      <ApplicationRoutes />
    </div>
  );
}
