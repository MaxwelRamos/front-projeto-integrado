import styled from '@emotion/styled'

export const Div = styled.div`
box-sizing: border-box;
`