import styled from '@emotion/styled'

export const Aside = styled.aside`
box-sizing: border-box;
background-color: #4169E1;
width: 100%;
text-align: center;
float: left;
`